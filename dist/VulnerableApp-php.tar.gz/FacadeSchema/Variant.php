<?php
namespace facadeSchema;
class Variant
{
    const UNSECURE = "UNSECURE";
    const SECURE = "SECURE";
}
?>
