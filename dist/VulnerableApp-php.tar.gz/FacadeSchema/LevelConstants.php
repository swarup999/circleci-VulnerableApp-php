<?php declare(strict_types=1);
namespace facadeSchema;
class LevelConstants
{
    const LEVEL_1 = "LEVEL_1";
    const LEVEL_2 = "LEVEL_2";
    const LEVEL_3 = "LEVEL_3";
    const LEVEL_4 = "LEVEL_4";
    const LEVEL_5 = "LEVEL_5";
    const LEVEL_6 = "LEVEL_6";
    const LEVEL_7 = "LEVEL_7";
    const LEVEL_8 = "LEVEL_8";
    const LEVEL_9 = "LEVEL_9";
    const LEVEL_10 = "LEVEL_10";
    const LEVEL_11 = "LEVEL_11";
    const LEVEL_12 = "LEVEL_12";
    const LEVEL_13 = "LEVEL_13";
}
