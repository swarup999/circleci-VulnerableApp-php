<?php
namespace facadeSchema;
class ResourceType
{
    const HTML = "HTML";
    const CSS = "CSS";
    const JAVASCRIPT = "JAVASCRIPT";
}
?>
